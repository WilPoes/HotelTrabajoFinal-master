package pe.edu.universidad.dto;

public class DtoCheckOutHabitacion {
	private int id;
	private double precio;

	public DtoCheckOutHabitacion() {
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

}
