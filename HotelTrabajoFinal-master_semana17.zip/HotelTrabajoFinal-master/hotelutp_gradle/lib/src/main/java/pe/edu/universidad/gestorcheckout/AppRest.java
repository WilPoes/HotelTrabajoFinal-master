package pe.edu.universidad.gestorcheckout;


import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("rs")
public class AppRest extends Application{
	

}
