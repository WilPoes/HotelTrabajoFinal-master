package pe.edu.universidad.dto;

public class DtoHabitaciones {
	private Integer habitacionId;
	private String descripcion;

	public DtoHabitaciones() {
		// TODO Auto-generated constructor stub
	}

	public Integer getHabitacionId() {
		return habitacionId;
	}

	public void setHabitacionId(Integer habitacionId) {
		this.habitacionId = habitacionId;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

}
